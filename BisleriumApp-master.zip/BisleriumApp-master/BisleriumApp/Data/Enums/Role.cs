﻿namespace BisleriumApp.Data.Enums;

public enum Role
{
    Admin,
    Staff,
}
