﻿

namespace BisleriumApp.Data.Enums;

public enum CustomerRole
{
    Normal,
    Regular
}
