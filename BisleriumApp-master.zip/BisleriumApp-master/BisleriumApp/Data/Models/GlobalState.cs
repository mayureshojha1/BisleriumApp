namespace BisleriumApp.Data.Models;

public class GlobalState
{
    public User CurrentUser { get; set; }
}
